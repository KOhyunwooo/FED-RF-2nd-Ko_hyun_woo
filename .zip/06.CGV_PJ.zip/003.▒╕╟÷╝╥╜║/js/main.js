// CGV PJ 메인 페이지 JS - main.js
